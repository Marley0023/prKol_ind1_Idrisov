﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace prKol_ind1_Idrisov
{
    internal class Program
    {
        static int Precedence(char op)
        {
            switch (op)
            {
                case '+':
                case '-':
                    return 1;
                case '*':
                case '/':
                    return 2;
                default:
                    return 0;
            }
        }

        static void InfixToPrefix(string infix)
        {
            Stack<char> operators = new Stack<char>();
            Stack<string> operands = new Stack<string>();

            for (int i = infix.Length - 1; i >= 0; i--)
            {
                char current = infix[i];

                if (current == ' ' || current == ',')
                {
                    continue;
                }
                else if (current == ')')
                {
                    operators.Push(current);
                }
                else if (current == '(')
                {
                    while (operators.Peek() != ')')
                    {
                        char op = operators.Pop();
                        string operand1 = operands.Pop();
                        string operand2 = operands.Pop();
                        operands.Push(op + operand2 + operand1);
                    }
                    operators.Pop(); 
                }
                else if (char.IsDigit(current))
                {
                    operands.Push(current.ToString());
                }
                else
                {
                    while (operators.Count > 0 && Precedence(current) < Precedence(operators.Peek()))
                    {
                        char op = operators.Pop();
                        string operand1 = operands.Pop();
                        string operand2 = operands.Pop();
                        operands.Push(op + operand2 + operand1);
                    }
                    operators.Push(current);
                }
            }

            while (operators.Count > 0)
            {
                char op = operators.Pop();
                string operand1 = operands.Pop();
                string operand2 = operands.Pop();
                operands.Push(op + operand2 + operand1);
            }

            Console.WriteLine("Prefix: " + operands.Pop());
        }
        static int EvaluateFormula(string formula)
        {
            Stack<char> stack = new Stack<char>();

            foreach (char c in formula)
            {
                if (c == ')')
                {
                    List<int> operands = new List<int>();
                    while (stack.Peek() != '(')
                    {
                        operands.Add(int.Parse(stack.Pop().ToString()));
                    }
                    stack.Pop();

                    char operation = stack.Pop();
                    int result = operation == 'M' ? operands.Max() : operands.Min();
                    stack.Push(result.ToString()[0]);
                }
                else if (c != ',' && c != ' ')
                {
                    stack.Push(c);
                }
            }

            return int.Parse(stack.Pop().ToString());
        }
        static int EvaluateFormula2(string formula2)
        {
            Stack<char> stack = new Stack<char>();

            foreach (char c in formula2)
            {
                if (c == ')')
                {
                    List<int> operands = new List<int>();
                    while (stack.Peek() != '(')
                    {
                        operands.Add(int.Parse(stack.Pop().ToString()));
                    }
                    stack.Pop(); // Удаляем открывающую скобку

                    char operation = stack.Pop();
                    int result2 = operation == 'm' ? (operands[0] - operands[1]) % 10 : (operands[0] + operands[1]) % 10;
                    stack.Push(result2.ToString()[0]);
                }
                else if (c != ',' && c != ' ')
                {
                    stack.Push(c);
                }
            }

            return int.Parse(stack.Pop().ToString());
        }
        static void Main(string[] args)
        {
            //задача 3
            string filePath = "t.txt";
            using (StreamReader sr = new StreamReader(filePath))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    Stack<char> stack = new Stack<char>();
                    foreach (char c in line)
                    {
                        stack.Push(c);
                    }
                    while (stack.Count > 0)
                    {
                        Console.Write(stack.Pop());
                    }
                    Console.WriteLine();
                }
            }

            //Задача 6
            Console.WriteLine("Введите операцию: ");
            string gg = Console.ReadLine();
            string infixExpression = gg;
            InfixToPrefix(infixExpression);

            //задача 8
            string filePath1 = "8.txt";
            string formula = File.ReadAllText(filePath1);
            int result = EvaluateFormula(formula);
            Console.WriteLine("Результат вычисления формулы: " + result);

            //задача 9
            string filePath2 = "9.txt";
            string formula2 = File.ReadAllText(filePath2);
            int result2 = EvaluateFormula2(formula2);
            Console.WriteLine("Результат вычисления формулы: " + result);

        }

}   }

